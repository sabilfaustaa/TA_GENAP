<html>
  <head>
    <title>Hospital Update</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/style_corona.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/bootstrap.css')); ?>">
  </head>
  <body style="background-color: #17234C;">
    <?php if(session('error')): ?>
    <div class="">
        <?php echo e(session('error')); ?>

    </div>
      <?php endif; ?>

      <?php if(count($errors) > 0): ?>
    <div class="">
      <strong>Perhatian</strong>
      <br />
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
      <?php endif; ?>

    
      
    <div class="container bg-light p-5 form-cont">
      <div class="header">
        <h1 class="display-4 mb-5" style="font-size: 30px;">Input Data Rumah Sakit</h1>
        <a href="<?php echo e(url('/corona')); ?>" class="btn btn-sm btn-warning">Back</a>
        <a href="<?php echo e(url('/aboutcorona')); ?>" class="btn btn-sm btn-danger">Home</a>
      </div>
      <div class="form-add">
        <form action="<?php echo e(url('corona', @$rs->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <?php if(!empty($rs)): ?>
          <?php echo method_field('PATCH'); ?>
        <?php endif; ?>


          <div class="form-group">
            <label for="exampleInputEmail1">Provinsi</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="provinsi" value="<?php echo e(old('provinsi', @$rs->provinsi)); ?>">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Kota</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="kota" value="<?php echo e(old('kota', @$rs->kota)); ?>">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Rumah Sakit</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="nama_rs" value="<?php echo e(old('nama_rs', @$rs->nama_rs)); ?>">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Alamat</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="alamat" value="<?php echo e(old('alamat', @$rs->alamat)); ?>">
          </div>
          <input class="btn btn-md btn-primary btn-add" type="submit" value="Simpan">
        </form>
        </div>
    </div>
    

  </body>
</html><?php /**PATH C:\xampp\htdocs\coronavirus\resources\views/corona/form.blade.php ENDPATH**/ ?>