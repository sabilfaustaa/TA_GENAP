<html>
	<head>
		<title>Corona Hospital</title>
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/bootstrap.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/style_corona.css')); ?>">
	</head>
	<body style="background-color: #17234C;">
		
		<div class="container bg-light">
		<?php if(session('success')): ?>
		<div class="alert alert-success">
			<?php echo e(session('success')); ?>

		</div>
		<?php endif; ?>

		<?php if(session('error')): ?>
		<div class="alert alert-error">
			<?php echo e(session('error')); ?>

		</div>
		<?php endif; ?>

			<h1 class="display-4 mb-5 pt-5" style="font-size: 30px;">Rumah Sakit Rujukan COVID-19</h1>
			<a href="<?php echo e(url('/aboutcorona')); ?>" class="btn btn-sm btn-danger mb-5 back pl-4 pr-4">Back</a>
			<a href="<?php echo e(url('/corona/create/')); ?>" class="btn btn-sm btn-primary mb-5 pl-4 pr-4">Tambah data</a>
			<table class="table table-striped">
				<thead>
					<tr>
						<th scope="col">No</th>
						<th scope="col">Provinsi</th>
						<th scope="col">Kota</th>
						<th scope="col">Rumah Sakit</th>
						<th scope="col">Alamat</th>
						<th scope="col" class="pl-5 pr-5" style="width: 200px">Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($loop->iteration); ?></td>
						<td><?php echo e($row->provinsi); ?></td>
						<td><?php echo e($row->kota); ?></td>
						<td><?php echo e($row->nama_rs); ?></td>
						<td><?php echo e($row->alamat); ?></td>
						<td>
							<a class="btn btn-sm btn-warning" href="<?php echo e(url('/corona/' . $row->id . '/edit')); ?>">Edit</a>
							<form action="<?php echo e(url('/corona', $row->id)); ?>" method="POST">
								<?php echo method_field('DELETE'); ?>
								<?php echo csrf_field(); ?>
								<button type="submit" class="btn btn-sm btn-danger">Delete</button>
							</form>	
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</body>
</html><?php /**PATH C:\xampp\htdocs\coronavirus\resources\views/corona.blade.php ENDPATH**/ ?>