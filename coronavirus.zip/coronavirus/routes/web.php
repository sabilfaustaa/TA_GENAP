<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/aboutcorona', function () {
    return view('landing');
});

Route::get('/corona','CoronaController@index');
Route::get('/corona/create', 'CoronaController@create');
Route::post('/corona', 'CoronaController@store');
Route::get('/corona/{id}/edit', 'CoronaController@edit' );
Route::patch('/corona/{id}', 'CoronaController@update');
Route::delete('/corona/{id}', 'CoronaController@destroy');


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

