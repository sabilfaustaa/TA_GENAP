<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CoronaController extends Controller
{
    public function index() {
        $data['rs'] = \DB::table('table_rs')->get();
        return view('corona', $data);
    }

    public function create() {
        return view('corona.form');
    }

    
    public function store(Request $request)
    {
        $rule = [
            'provinsi' => 'required|string',
            'kota' => 'required|string',
            'nama_rs' => 'required|string',
            'alamat' => 'required|string',
        ];
        $this->validate($request, $rule);

        $input = $request->all();
        unset($input['_token']);
        $status = \DB::table('table_rs')->insert($input);

        if ($status) {
            return redirect('/corona')->with('success', 'Data berhasil ditambahkan');
        } else{
            return redirect('/corona')->with('error', 'Data gagal ditambahkan');
        }
    }

    public function edit(Request $request, $id) {
        $data['rs'] = \DB::table('table_rs')->find($id);
        return view('corona.form', $data);
    }

    public function update(Request $request, $id) {
        $rule = [
            'provinsi' => 'required|string',
            'kota' => 'required|string',
            'nama_rs' => 'required|string',
            'alamat' => 'required|string',
        ];
        $this->validate($request, $rule);

        $input = $request->all();
        unset($input['_token']);
        unset($input['_method']);

        $status = \DB::table('table_rs')->where('id', $id)->update($input);

        if ($status) {
            return redirect('/corona')->with('success', 'Data berhasil diubah');
        } else{
            return redirect('/corona')->with('error', 'Data gagal diubah');
        }
    }

    public function destroy(Request $request, $id)
    {
        $status = \DB::table('table_rs')->where('id', $id)->delete();

        if ($status) {
            return redirect('/corona')->with('success', 'Data berhasil diubah');
        } else{
            return redirect('/corona')->with('error', 'Data gagal diubah');
        }
    }
}
