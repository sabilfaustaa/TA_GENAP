<html>
  <head>
    <title>Hospital Update</title>
    <link rel="stylesheet" type="text/css" href="{{ asset('/css/style_corona.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('/css/bootstrap.css') }}">
  </head>
  <body style="background-color: #17234C;">
    @if(session('error'))
    <div class="">
        {{ session('error') }}
    </div>
      @endif

      @if(count($errors) > 0)
    <div class="">
      <strong>Perhatian</strong>
      <br />
      <ul>
        @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
        @endforeach
      </ul>
    </div>
      @endif

    
      
    <div class="container bg-light p-5 form-cont">
      <div class="header">
        <h1 class="display-4 mb-5" style="font-size: 30px;">Input Data Rumah Sakit</h1>
        <a href="{{ url('/corona') }}" class="btn btn-sm btn-warning">Back</a>
        <a href="{{ url('/aboutcorona') }}" class="btn btn-sm btn-danger">Home</a>
      </div>
      <div class="form-add">
        <form action="{{ url('corona', @$rs->id) }}" method="POST">
        @csrf

        @if(!empty($rs))
          @method('PATCH')
        @endif


          <div class="form-group">
            <label for="exampleInputEmail1">Provinsi</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="provinsi" value="{{ old('provinsi', @$rs->provinsi) }}">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Kota</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="kota" value="{{ old('kota', @$rs->kota) }}">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Rumah Sakit</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="nama_rs" value="{{ old('nama_rs', @$rs->nama_rs) }}">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Alamat</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="alamat" value="{{ old('alamat', @$rs->alamat) }}">
          </div>
          <input class="btn btn-md btn-primary btn-add" type="submit" value="Simpan">
        </form>
        </div>
    </div>
    

  </body>
</html>