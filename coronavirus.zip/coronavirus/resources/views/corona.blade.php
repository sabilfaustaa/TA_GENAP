<html>
	<head>
		<title>Corona Hospital</title>
		<link rel="stylesheet" type="text/css" href="{{ asset('/css/bootstrap.css') }}">
		<link rel="stylesheet" type="text/css" href="{{ asset('/css/style_corona.css') }}">
	</head>
	<body style="background-color: #17234C;">
		
		<div class="container bg-light">
		@if (session('success'))
		<div class="alert alert-success">
			{{ session('success') }}
		</div>
		@endif

		@if (session('error'))
		<div class="alert alert-error">
			{{ session('error') }}
		</div>
		@endif

			<h1 class="display-4 mb-5 pt-5" style="font-size: 30px;">Rumah Sakit Rujukan COVID-19</h1>
			<a href="{{ url('/aboutcorona') }}" class="btn btn-sm btn-danger mb-5 back pl-4 pr-4">Back</a>
			<a href="{{ url('/corona/create/') }}" class="btn btn-sm btn-primary mb-5 pl-4 pr-4">Tambah data</a>
			<table class="table table-striped">
				<thead>
					<tr>
						<th scope="col">No</th>
						<th scope="col">Provinsi</th>
						<th scope="col">Kota</th>
						<th scope="col">Rumah Sakit</th>
						<th scope="col">Alamat</th>
						<th scope="col" class="pl-5 pr-5" style="width: 200px">Aksi</th>
					</tr>
				</thead>
				<tbody>
					@foreach ($rs as $row)
					<tr>
						<td>{{ $loop->iteration }}</td>
						<td>{{ $row->provinsi }}</td>
						<td>{{ $row->kota }}</td>
						<td>{{ $row->nama_rs }}</td>
						<td>{{ $row->alamat }}</td>
						<td>
							<a class="btn btn-sm btn-warning" href="{{ url('/corona/' . $row->id . '/edit') }}">Edit</a>
							<form action="{{ url('/corona', $row->id) }}" method="POST">
								@method('DELETE')
								@csrf
								<button type="submit" class="btn btn-sm btn-danger">Delete</button>
							</form>	
						</td>
					</tr>
					@endforeach
				</tbody>
			</table>
		</div>
	</body>
</html>