<!DOCTYPE html>
<html>
	<head>
		<title>Corona Website</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- CSS -->
		<link rel="stylesheet" type="text/css" href="assets/style_index.css">
		
		<!-- Laravel CSS  -->
		<link rel="stylesheet" type="text/css" href="{{ asset('/css/style_index.css') }}">
		<link rel="stylesheet" type="text/css" href="{{ asset('/css/bootstrap.css') }}">

		<!-- Bootstrap -->
		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">

		<!-- JQuery Script -->
    <script type="text/javascript" src="js/jquery-3.4.1.js"></script>
		<link href="{{ asset('/js/jquery-3.4.1.js') }}">

	</head>
	<body style="background-color: #f4f4f4">

		<div class="home">
			<!-- Navigation Bar -->
			<div class="navigation">
				<div class="container">
					<nav class="navbar navbar-expand-lg">
					  <a class="navbar-brand" href="#">Covid19</a>
					  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
					    <span class="navbar-toggler-icon"></span>
					  </button>
					  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
					    <div class="navbar-nav">
								<a class="nav-item nav-link active" href="#">Home <span class="sr-only">(current)</span></a>
								<a class="nav-item nav-link" href="{{ url('/corona') }}">Hospital</a>
					      <a class="nav-item nav-link" href="#">About</a>
					      <a class="nav-item nav-link" href="#">Prevention</a>
					      <a class="nav-item nav-link" href="#">Contagious</a>
					      <a class="nav-item nav-link" href="#">Victim</a>
					    </div>
					  </div>
					</nav>
				</div>
			</div>
			<!-- Navigation Bar End -->

			<!-- Jumbotron -->

			<div class="container">
				<div class="jumbotron jumbotron-fluid text-light" style="background-color: #17234C;">
					<div class="container">  
						<div class="row">
						  <div class="col-6 header-jumbotron pr-5">
						    <h1 class="display-4">STAY <span>HOME</span> <br> FOR STAY <span>SAFE</span></h1>
						    <a class="btn btn-md btn-primary pl-4 pr-4">Learn More</a>
					    </div>
					    <div class="col-3 jumbo-img">
					    	<img src="{{ asset('/images/jumbotron-img.png') }}">
					    </div>
				    </div>
				  </div>			
				</div>
			</div>
		</div>

		<!-- Jumbotron End -->

		<!-- About Corona -->

		<div class="container">
			<div class="about corona">
				<div class="row">
					<div class="col">
						<img src="{{ asset('/images/covid.png') }}">
					</div>
					<div class="col-7">
						<div class="header">
							<p class="sub-title">What is Covid-19 ?</p>
							<p class="title">Coronavirus</p>
							<p class=" description">Coronavirus disease (COVID-19) is an infectious disease caused by a newly discovered coronavirus.
													Most people infected with the COVID-19 virus will experience mild to moderate respiratory illness and recover without requiring special treatment.  
													Older people, and those with underlying medical problems like cardiovascular disease, diabetes, 
													chronic respiratory disease, and cancer are more likely to develop serious illness.
													The best way to prevent and slow down transmission is be well informed about the COVID-19 virus, the disease it causes and how it spreads. 
													At this time, there are no specific vaccines or treatments for COVID-19. However, there are many ongoing clinical trials evaluating potential treatments.
													WHO will continue to provide updated information as soon as clinical findings become available.</p>
							<a href="#" class="btn btn-sm btn-primary pr-3 pl-3">See Image</a>
						</div>
					</div>
				</div>
			</div>	
		</div>

		<!-- About Corona End -->

		<!-- Contagious	-->

		<div class="container">
			<div class="about contagious">
				<div class="row">
					<div class="col">
						<div class="header">
							<p class="sub-title">How Can Contagious it ?</p>
							<p class="title">Coronavirus</p>
							<p class=" description">The virus that causes COVID-19 is thought to spread mainly from person to person, mainly through respiratory droplets produced when an infected person coughs or sneezes. These droplets can land in the mouths or noses of people who are nearby or possibly be inhaled into the lungs. Spread is more likely when people are in close contact with one another (within about 6 feet).
							</p>
							<ul>
								<li>Air Transmission</li>
								<li>Contained Objects</li>
								<li>Human Contacts</li>
							</ul>
						</div>
					</div>
					<div class="col">
						<img src="{{ asset('/images/caca.png') }}">
					</div>
				</div>
			</div>	
		</div>

		<!-- Contagious End -->

		<!-- Prevention -->

		<div class="container">
			<div class="about prevention">
				<div class="row">
					<div class="col">
						<div class="header">
							<p class="sub-title">How to Prevent it ?</p>
							<p class="title">Coronavirus</p>
							<p class="description"></div>
					</div>
				</div>
				<div class="row" style="margin-left: 1rem;">
					<div class="col">
						<div class="card" style="width: 16rem;">
							<img src="{{ asset('/images/cucitangan.png') }}" class="card-img-top" alt="...">
							<div class="card-body">
								<p class="card-text">Wash your hands</p>
							</div>
						</div>
					</div>
					<div class="col">
						<div class="card" style="width: 16rem;">
							<img src="{{ asset('/images/handsinitizer.png') }}" class="card-img-top" alt="...">
							<div class="card-body">
								<p class="card-text">Use hand sanitizer</p>
							</div>
						</div>
					</div>
					<div class="col">
						<div class="card" style="width: 16rem;">
							<img src="{{ asset('/images/tissue.jpg') }}" class="card-img-top" alt="...">
							<div class="card-body">
								<p class="card-text">Bring tissue</p>
							</div>
						</div>
					</div>
					<div class="col">
						<div class="card" style="width: 16rem;">
							<img src="{{ asset('/images/gloves.jpg') }}" class="card-img-top" alt="...">
							<div class="card-body">
								<p class="card-text">Wear gloves</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Prevention End -->

		<!-- Symptoms -->
		<div class="container">
			<div class="about symptoms">
				<div class="row">
					<div class="col">
						<div class="header">
							<p class="sub-title">The Symptoms </p>
							<p class="title">Coronavirus</p>
						</div>
					</div>
				</div>
				<div class="row" style="margin-left: 1rem;">
					<div class="col">
						<div class="card" style="width: 16rem;">
							<img src="{{ asset('/images/cough.png') }}" class="card-img-top" alt="...">
							<div class="card-body">
								<p class="card-text">Coughing continously</p>
							</div>
						</div>
					</div>
					<div class="col">
						<div class="card" style="width: 16rem;">
							<img src="{{ asset('/images/demam.png') }}" class="card-img-top" alt="...">
							<div class="card-body">
								<p class="card-text">High Fever</p>
							</div>
						</div>
					</div>
					<div class="col">
						<div class="card" style="width: 16rem;">
							<img src="{{ asset('/images/flu.png') }}" class="card-img-top" alt="...">
							<div class="card-body">
								<p class="card-text">Influenza</p>
							</div>
						</div>
					</div>
					<div class="col">
						<div class="card" style="width: 16rem;">
							<img src="{{ asset('/images/breath.png') }}" class="card-img-top" alt="...">
							<div class="card-body">
								<p class="card-text">Difficult to breath</p>
							</div>
						</div>
					</div>
				</div>				
			</div>
		</div>
		<!-- Symptoms End -->

		<!-- Victim -->
		

		<div class="victim">
			<div class="container">
				<div class="header">
					<div class="row">
						<div class="col">
							<h4 style="color:#19E8E2;">Victim</h4>
						</div>
					</div>
					<div class="row">
						<div class="col">
							<p>Source : Kementrian Kesehatan & JHU <br>	Date : <?= date('d-m-Y'); ?></p>
						</div>
					</div>
				</div>
				<div class="row vic">
					<div class="col-3 tot-victim bg-danger" style="margin-right: 50px;">
						<table>
							<tbody id="total-positif"></tbody>
						</table><p class="data">720000</p><br>
						<P class="data-head">Total Positif</P>
					</div>
					<div class="col-3 bg-warning" style="margin-right: 50px;">
						<p class="data">11000</p><br>
						<P class="data-head">Total Meninggal</P>
					</div>
					<div class="col-3 bg-primary">
						<p class="data">23000</p><br>
						<P class="data-head">Total Sembuh</P>
					</div>
				</div>
				<div class="row victim-img">
					<img src="{{ asset('/images/world.png') }}" alt="world">
				</div>
			</div>
		</div>

		<script type="text/javascript">
			$.ajax({
				url				: "https://api.covid19api.com/summary",
				type 			: "GET",
				dataType	: "JSON",
				success 	: function(data){
					console.log(data);
					console.log(data.Global);

					$.each(data.Global, function(key, value) {
						$("#total-positif").append("<tr><td>" + key + ":" + value + "</td></tr>")
					});
				}
			});
		</script>

		<!-- Victim End -->

		<!-- Our Team -->

		<div class="container our-team">
			<div class="header">
				<div class="row">
					<div class="col">
						<h2>Our Team</h2>
					</div>
				</div>
				<div class="row">
					<div class="col">
						<p>This is Team Maker this Website. You can follow us on Social Media</p>
					</div>
				</div>
			</div>
			<div class="team">
				<div class="row">
					<div class="col-3" style="width: 16rem; margin-left:80px">
						<div class="img-team">
							<img src="{{ asset('/images/sabil.jpeg') }}" alt="img-team">
						</div>
						<div class="name-team">
							<h4>Muhamad Sabil Fausta</h4>
						</div>
						<div class="quote">
							<p>Mengertilah kode dari dia karena dia bukan php</p>
						</div>
					</div>
					<div class="col-3" style="width: 16rem;">
						<div class="img-team">
							<img src="{{ asset('/images/krisna.jpeg') }}" alt="img-team" style="height: 300px;">
						</div>
						<div class="name-team">
							<h4>Krisna Riyadi</h4>
						</div>
						<div class="quote">
							<p>Jangan takut sama python karena dia cuman bahasa</p>
						</div>
					</div>
					<div class="col-3">
						<div class="img-team">
							<img src="{{ asset('/images/fotoprofil.jpg') }}" alt="img-team">
						</div>
						<div class="name-team">
							<h4>Azka Zaki Ramadhan</h4>
						</div>
						<div class="quote">
							<p>Jangan takut Error, takutlah pada Allah SWT </p>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Our Team End -->

		<!-- Footer -->

		<div class="footer">
			<div class="container">
				<div class="row contact-us">
					<div class="col-7">
						<p>Do you have any Symptoms COVID-19 ? <br> Let's Contact Us</p><br>
						<a href="#" class="btn btn-md btn-primary  pl-4 pr-4">Contact Us</a>
					</div>
				</div>
				<div class="row">
					<div class="col">
						<p>Copyright 2020 Made by Our Team. All Right Reserved.</p>
					</div>
				</div>
			</div>
		</div>

		<!-- Footer End -->

    
	</body>
</html>